#!/bin/sh
# директория для инсталляции
INSTALL_DIR=/opt/postcode

systemctl stop postCode

rm $INSTALL_DIR/postCode

cp postCode /$INSTALL_DIR

systemctl start postCode
