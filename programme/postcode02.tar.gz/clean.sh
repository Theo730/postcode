#!/bin/sh
>/opt/postcode/log/debug.log
>/opt/postcode/log/error.log
>/opt/postcode/log/info.log

