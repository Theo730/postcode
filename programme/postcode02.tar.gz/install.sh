#!/bin/sh
# директория для инсталляции
INSTALL_DIR=/opt/postcode
# название программ
PROG1=postCode
mkdir $INSTALL_DIR
mkdir $INSTALL_DIR/log
cp $PROG1 $INSTALL_DIR
cp clean.sh $INSTALL_DIR/log
cp -r test $INSTALL_DIR/
cp -r app $INSTALL_DIR/
# инициализируем

mysql -e "DROP DATABASE IF EXISTS postcode"
mysql -e "CREATE DATABASE postcode CHARACTER SET utf8 COLLATE utf8_general_ci;"
mysql -e "GRANT ALL ON postCodeUser.* TO 'postcode'@'localhost' IDENTIFIED BY 'postCodePassword';"

# инсталлируем в systemd
echo '[Unit]
Description=PostCode RestAPI
After=mysql.service
[Service]
Type=simple
PIDFile=/var/run/'$PROG1'.pid
ExecStart='$INSTALL_DIR/$PROG1' -config='$INSTALL_DIR'
ExecReload=/bin/kill -HUP $MAINPID
Restart=always
[Install]
WantedBy=multi-user.target
' > /etc/systemd/system/$PROG1.service

systemctl enable $PROG1
systemctl start $PROG1
