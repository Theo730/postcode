#!/bin/sh
# директория для инсталляции
INSTALL_DIR=/opt/postcode

systemctl stop postCode
systemctl disable postCode

rm -R $INSTALL_DIR
rm /etc/systemd/system/postCode.service
mysql -e "DROP DATABASE postcode"
