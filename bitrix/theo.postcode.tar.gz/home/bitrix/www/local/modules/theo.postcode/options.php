<?
$module_id = 'theo.postcode';

require_once($_SERVER['DOCUMENT_ROOT'].'/local/modules/'.$module_id.'/include.php');
IncludeModuleLangFile($_SERVER['DOCUMENT_ROOT'].'/local/modules/'.$module_id.'/options.php');
include('CModuleOptions.php');

$showRightsTab = true;

$arTabs = array(
   array(
      'DIV' => 'edit1',
      'TAB' => 'Настройки',
      'ICON' => '',
      'TITLE' => 'Настройки'
   )
);

$arGroups = array(
   'POSTCODE'	=> array('TITLE' => 'Основные настройки для работы и проверки почтовых индексов(Почта России).', 'TAB' => 0),
);

$arOptions = array(
   'POSTCODE_ENABLE' => array(
      'GROUP' => 'POSTCODE',
      'TITLE' => 'Включить работу с PostCode',
      'TYPE' => 'CHECKBOX',
      'REFRESH' => 'Y',
      'DEFAULT' =>  'Y',
      'SORT' => '0',
      'NOTES' => ''
   ),
    'POSTCODE_URI_API' => array(
      'GROUP' => 'POSTCODE',
      'TITLE' => 'URI для PostCode',
      'TYPE' => 'STRING',
      'DEFAULT' =>  'http://192.168.2.5:5553/api/v1/',
      'SORT' => '10',
      'NOTES' => ''
   ),
   'POSTCODE_LOGIN' => array(
      'GROUP' => 'POSTCODE',
      'TITLE' => 'Login для доступа к PostCode',
      'TYPE' => 'STRING',
      'DEFAULT' => 'user',
      'SORT' => '10',
      'NOTES' => ''
   ),
    'POSTCODE_PASSWORD' => array(
      'GROUP' => 'POSTCODE',
      'TITLE' => 'Password для доступа к PostCode',
      'TYPE' => 'STRING',
      'DEFAULT' => 'passwd',
      'SORT' => '10',
      'NOTES' => ''
   ),
);

$opt = new CModuleOptions($module_id, $arTabs, $arGroups, $arOptions, $showRightsTab);
$opt->ShowHTML();

?>

