<?
/*
Date: 20.09.2017
User: theo
*/

namespace Theo\PostCode;

class PostCode{
	private $login		=	'';
	private $password	=	'';
	private $uri		=	'';
	private $keyID		=	'';
	private $keyBase64	=	'';
	
	public function __construct($inLogin, $inPass, $inUri){
	    $this->login	=	$inLogin;
	    $this->password	=	$inPass;
	    $this->uri		=	$inUri;
	}
	private function getKeyBase64(){
	    $this->keyBase64  = base64_encode($this->login.':'.$this->password);
	    return;
	}
	public function validatePostCode(int $postIndex){
	    $this->getKeyBase64();
	    $opts = array(
	    	'http'	=> array(
		    'header'		=> 'Authorization: Basic ' . $this->keyBase64,
		    'method'		=> 'GET',
		    ),
		'ssl'	=> array(
		    'verify_peer'	=> false,
		    'verify_peer_name'	=> false,
		),
	    );
	    $context = stream_context_create($opts);
	    $result = file_get_contents($this->uri."validatePostIndex/".$postIndex , false, $context);
	    return $result;
	}
}
