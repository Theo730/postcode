<?
use Bitrix\Main\Application;
use Bitrix\Main\Loader;
use Bitrix\Main\Localization\Loc;
use Bitrix\Main\ModuleManager;

Loc::loadMessages(__FILE__);

Class Theo_postcode extends CModule{
        var $MODULE_ID = "theo.postcode";
        var $MODULE_VERSION;
        var $MODULE_VERSION_DATE;
        var $MODULE_NAME;
        var $MODULE_DESCRIPTION;
        var $errors;

    function __construct(){
	$this->MODULE_VERSION = "0.0.1";
	$this->MODULE_VERSION_DATE = "20.03.2019";
	$this->MODULE_NAME = "Модуль PostCode";
        $this->MODULE_DESCRIPTION = "Модуль для работы с почтовыми индексами почты России.";
    }

    function DoInstall(){
	$this->InstallFiles();
	ModuleManager::RegisterModule("theo.postcode");
	return true;
    }
    
    function DoUninstall(){
	$this->UnInstallFiles();
	ModuleManager::UnRegisterModule("theo.postcode");
	return true;
    }

    function InstallFiles(){
	return true;
    }

    function UnInstallFiles(){
	return true;
    }
}
