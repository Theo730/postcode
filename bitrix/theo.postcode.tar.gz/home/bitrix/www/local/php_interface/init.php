<?php
defined('B_PROLOG_INCLUDED') || die;
include_once($_SERVER["DOCUMENT_ROOT"]."/local/php_interface/validators/val_postcode.php");
?>