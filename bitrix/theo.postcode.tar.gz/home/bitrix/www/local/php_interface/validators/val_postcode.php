<?php
/**
  Created by theo
  Date: 07.03.2019 
*/

namespace theoValidator;

use \Bitrix\Main\EventManager;

class FormValidatorPostCode{
    function getDescription(){
        return array(
            'NAME' => 'PostCode',
            'DESCRIPTION' => 'почтовый индекс',
            'TYPES' => array('text'),
            'SETTINGS' => array(__CLASS__, 'getSettings'),
            'CONVERT_TO_DB' => array(__CLASS__, 'toDB'), 
            'CONVERT_FROM_DB' => array(__CLASS__, 'fromDB'), 
            'HANDLER' => array(__CLASS__, 'doValidate')
        );
    }
    function getSettings(){
        return array();
    }
    function toDB($arParams){
        return serialize($arParams);
    }
    function fromDB($strParams){
        return unserialize($strParams);
    }
    function doValidate($arParams, $arQuestion, $arAnswers, $arValues){
        global $APPLICATION;
	if((\COption::GetOptionString("theo.postcode", 'POSTCODE_ENABLE', 'Y') == 'Y')&&(\Bitrix\Main\Loader::includeModule("theo.postcode"))){
    	    $serverURI		= \COption::GetOptionString("theo.postcode", 'POSTCODE_URI_API', '');
	    $serverLogin	= \COption::GetOptionString("theo.postcode", 'POSTCODE_LOGIN', '');
    	    $serverPassword	= \COption::GetOptionString("theo.postcode", 'POSTCODE_PASSWORD', '');
            $postCode		= new \Theo\PostCode\PostCode($serverLogin, $serverPassword, $serverURI);
            
            foreach ($arValues as $value){
		if(strlen(trim($value))==0) continue;
        	if($postCode->validatePostCode(intval($value))<1){
            		$APPLICATION->ThrowException('Веденного почтового индекса не существует '.$arQuestion['TITLE'].'');
            		return false;
    		}
    	    }
    	}
	return true;
    }
}
?>